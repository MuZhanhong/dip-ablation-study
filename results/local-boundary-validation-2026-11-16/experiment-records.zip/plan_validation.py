"""Freeze two follow-up batches selected after the exploratory 40-run results."""
import csv
import hashlib
import json
from pathlib import Path
from run_local_sweeps import source_hashes, stamp, save_json

ROOT=Path(__file__).resolve().parent
REPO=ROOT/'source_repository'

def make(kind):
    jobs=[]
    if kind=='model_seed':
        for seed in [1,2,3,4]:
            for net in [1,3]:
                for gap in [16,24]:
                    jobs.append(dict(sweep='model_seed_validation',image_type='stripes',gap_size=gap,
                                     blur_scale=None,image_seed=0,model_seed=seed,network=net))
    else:
        for image in [1,2,3,4]:
            for net in [1,3]:
                for ell in [4,8]:
                    jobs.append(dict(sweep='image_seed_validation',image_type='blurred_noise',gap_size=16,
                                     blur_scale=ell,image_seed=image,model_seed=0,network=net))
    for i,j in enumerate(jobs,1):
        j.update(run_id=f'{kind}_{i:03d}',channels=16,levels=4,steps=2000,log_every=50,
                 learning_rate=.01,noise_scale=.1,size=64,heldout_fraction=.05,heldout_seed=0,
                 ssim_window=3,selection='heldout')
    assert len(jobs)==16
    assert len({(j['network'],j['gap_size'],j['blur_scale'],j['model_seed'],j['image_seed']) for j in jobs})==16
    batch=ROOT/f'batch-{kind}'
    batch.mkdir(exist_ok=False)
    manifest=dict(created_utc=stamp(),scope='user-authorized local follow-up validation',
        status='authorized; frozen before new runs',repository=str(REPO),source_sha256=source_hashes(REPO),
        planned_runs=16,jobs=jobs,notes=[
            'Follow-up selected after inspecting the first 40 seed-zero results; not a blind original prediction.',
            'The first 40 runs remain unchanged. Relevant original seed-zero rows are included only at analysis time.',
            'Model seed changes both weights and fixed input noise. Image-seed batch fixes model seed zero.',
            'Primary outcome: selected-checkpoint gap MSE. Also report Pearson r, final MSE and matched-information harmonic.',
            'All comparisons are paired by the varied seed. Report every seed; no result-dependent exclusions.',
            'Mean/SD describe five seeds including original seed zero; do not treat gap pixels as independent replicates.',
            'No GitHub Actions workflow is triggered.'])
    save_json(batch/'manifest.json',manifest)
    with (batch/'run_matrix.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(jobs[0]));w.writeheader();w.writerows(jobs)
    return manifest

if __name__=='__main__':
    for kind in ['model_seed','image_seed']:
        print(kind,make(kind)['planned_runs'])
    frozen={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in [ROOT/'plan_validation.py',ROOT/'run_local_sweeps.py',
                      ROOT/'batch-model_seed/manifest.json',ROOT/'batch-image_seed/manifest.json']}
    save_json(ROOT/'frozen_plan_hashes.json',dict(time_utc=stamp(),sha256=frozen))
