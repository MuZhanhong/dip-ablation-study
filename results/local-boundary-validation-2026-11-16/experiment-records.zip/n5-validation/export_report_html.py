"""Export the local Markdown results as a self-contained, offline HTML report."""
from pathlib import Path
from html import escape
import base64
import re

ROOT=Path(__file__).resolve().parent

def inline(s):
    s=escape(s)
    s=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',s)
    s=re.sub(r'`(.+?)`',r'<code>\1</code>',s)
    return s

def render(text):
    lines=text.splitlines(); out=[]; i=0; in_list=False
    while i<len(lines):
        s=lines[i].strip()
        if in_list and not s.startswith('- '):
            out.append('</ul>');in_list=False
        if not s:
            i+=1;continue
        if s.startswith('|'):
            table=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                cells=[c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?',c) for c in cells):
                    table.append(cells)
                i+=1
            out.append('<div class="table"><table>')
            for row,cells in enumerate(table):
                tag='th' if row==0 else 'td'
                out.append('<tr>'+''.join(f'<{tag}>{inline(c)}</{tag}>' for c in cells)+'</tr>')
            out.append('</table></div>');continue
        match=re.fullmatch(r'!\[(.*?)\]\((.*?)\)',s)
        if match:
            path=ROOT/match[2]
            data=base64.b64encode(path.read_bytes()).decode('ascii')
            out.append(f'<figure><img alt="{escape(match[1])}" src="data:image/png;base64,{data}"></figure>')
        elif s.startswith('#'):
            level=len(s)-len(s.lstrip('#'))
            out.append(f'<h{level}>{inline(s[level:].strip())}</h{level}>')
        elif s.startswith('- '):
            if not in_list:
                out.append('<ul>');in_list=True
            out.append('<li>'+inline(s[2:])+'</li>')
        else:
            out.append('<p>'+inline(s)+'</p>')
        i+=1
    if in_list:out.append('</ul>')
    return '\n'.join(out)

css='''body{margin:0;background:#f4f6f8;color:#172b3a;font:16px/1.8 "Microsoft YaHei",system-ui,sans-serif}
main{max-width:1160px;margin:32px auto;padding:36px 48px;background:white;border-radius:12px;box-shadow:0 4px 24px #2030400c}
h1{font-size:30px;line-height:1.4;margin:0 0 24px;color:#14344d}h2{font-size:23px;border-top:1px solid #e4e9ed;padding-top:24px;margin-top:36px}
strong{color:#005b78}img{width:100%;height:auto}figure{margin:24px 0}.table{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:14px;margin:20px 0}
th{background:#eaf1f5;text-align:left}td,th{padding:9px 12px;border-bottom:1px solid #dde5eb}tr:nth-child(2n){background:#f8fafb}
code{font-family:Consolas,monospace;background:#f1f4f6;padding:2px 5px;border-radius:3px}li{margin:9px 0}
@media print{body{background:white}main{margin:0;padding:0;box-shadow:none}figure,table{break-inside:avoid}h2{break-after:avoid}}
@media(max-width:700px){main{margin:0;padding:20px}h1{font-size:24px}}'''
source=(ROOT/'N5验证结果.md').read_text(encoding='utf-8')
page='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>N5缺口宽度与深度验证</title><style>'+css+'</style><main>'+render(source)+'</main></html>'
(ROOT/'N5验证结果.html').write_text(page,encoding='utf-8')
print('Exported offline report; bytes:',len(page.encode('utf-8')))
