"""Reconstruct every selected/final prediction from its saved weights and input seed."""
from pathlib import Path
import csv
import json
import sys
import numpy as np
import torch

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source_repository'))
from src.models import DIPHourglass, ablation_config

torch.set_num_threads(4)
checks=[]
markers=list((ROOT/'batch-n5/runs').glob('*/attempt_*/COMPLETE.json'))
for marker in sorted(markers):
    p=marker.parent
    cfg=json.loads((p/'config.json').read_text(encoding='utf-8'))
    summary=json.loads(marker.read_text(encoding='utf-8'))
    torch.manual_seed(cfg['model_seed'])
    model=DIPHourglass(ablation_config(cfg['network'],channels=cfg['channels'],levels=cfg['levels'])).to('cuda')
    generator=torch.Generator(device='cpu').manual_seed(cfg['model_seed'])
    z=(torch.randn(1,cfg['channels'],64,64,generator=generator)*cfg['noise_scale']).to('cuda')
    for kind in ['selected','final']:
        weights='best_model_state.pt' if kind=='selected' and cfg['selection']=='heldout' else 'final_model_state.pt'
        model.load_state_dict(torch.load(p/weights,map_location='cuda',weights_only=True))
        model.train()
        with torch.no_grad():
            actual=model(z)[0,0].cpu().numpy()
        expected=np.load(p/f'{kind}_prediction.npy',allow_pickle=False)
        error=float(np.max(np.abs(actual-expected)))
        assert np.allclose(actual,expected,rtol=1e-5,atol=1e-6),(cfg['run_id'],kind,error)
        checks.append(dict(run_id=cfg['run_id'],prediction=kind,weight_file=weights,max_absolute_error=error,passed=True))
    del model,z
    torch.cuda.empty_cache()
with (ROOT/'checkpoint_verification.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(checks[0]));w.writeheader();w.writerows(checks)
print(f'Passed {len(checks)} checkpoint reconstructions; max error {max(c["max_absolute_error"] for c in checks):.9g}')
