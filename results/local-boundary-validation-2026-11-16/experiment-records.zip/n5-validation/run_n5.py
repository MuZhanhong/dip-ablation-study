from pathlib import Path
from types import SimpleNamespace
from run_local_sweeps import run
if __name__=='__main__':
    run(SimpleNamespace(command='run',batch=Path(__file__).resolve().parent/'batch-n5',
                        device='cuda',threads=4,limit=0))
