"""Simple inpainting baselines."""
