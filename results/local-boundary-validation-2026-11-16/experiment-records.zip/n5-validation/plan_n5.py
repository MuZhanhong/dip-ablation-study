"""Freeze eight N5 repeats before their execution; retain original seed zero separately."""
from pathlib import Path
from types import SimpleNamespace
import csv
import shutil
import hashlib
from run_local_sweeps import source_hashes,stamp,save_json,run

ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    batch=ROOT/'batch-n5';batch.mkdir(exist_ok=False)
    jobs=[]
    for seed in [1,2,3,4]:
        for gap in [24,32]:
            jobs.append(dict(sweep='n5_model_seed_validation',image_type='stripes',gap_size=gap,
                blur_scale=None,image_seed=0,model_seed=seed,network=5,
                run_id=f'n5_{len(jobs)+1:03d}',channels=16,levels=4,steps=2000,
                log_every=50,learning_rate=.01,noise_scale=.1,size=64,
                heldout_fraction=.05,heldout_seed=0,ssim_window=3,selection='heldout'))
    assert len(jobs)==8
    save_json(batch/'manifest.json',dict(created_utc=stamp(),status='authorized and frozen before new runs',
        scope='N5 follow-up chosen after initial exploration',repository=str(ROOT/'source_repository'),
        source_sha256=source_hashes(ROOT/'source_repository'),planned_runs=8,jobs=jobs,
        notes=['Compare gap32 minus gap24 for every model seed, including the archived seed zero.',
               'Model seed changes both weights and fixed input noise; target and held-out seed remain zero.',
               'Primary outcome is selected-checkpoint gap MSE; gap error never selects a checkpoint.',
               'Also inspect ring-wise MSE/r from the edge to the centre. Report every seed.',
               'Five-seed and new-only four-seed summaries are descriptive, without significance claims.']))
    with (batch/'run_matrix.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(jobs[0]));w.writeheader();w.writerows(jobs)
    original=ROOT.parent/'yudi-validation-32-2026-11-16/original-exploration/batch/runs'
    for run_id in ['run_0034','run_0035']:
        shutil.copytree(original/run_id,ROOT/'reference-seed0'/run_id)
    save_json(ROOT/'frozen_plan_hashes.json',dict(time_utc=stamp(),sha256={
        p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
        for p in [ROOT/'plan_n5.py',ROOT/'run_local_sweeps.py',batch/'manifest.json']}))
    print('Frozen 8 new runs and copied 2 unchanged reference records; no training in this command.')
