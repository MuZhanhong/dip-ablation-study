"""Draw the prior independent-image validation against its matched harmonic baseline."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
with (ROOT/'prior-validation_seed_level.csv').open(encoding='utf-8-sig') as f:
    rows=[r for r in csv.DictReader(f) if r['family']=='image_seed']
assert len(rows)==20
fig,axes=plt.subplots(1,2,figsize=(12,4.8),constrained_layout=True)
for ax,metric,title in zip(axes,['gap_mse','gap_r'],['Gap MSE (lower is better)','Gap correlation (higher is better)']):
    for model,color in [('1','#2166ac'),('3','#7b3294'),('harmonic','#555555')]:
        for seed in range(5):
            part=sorted([r for r in rows if int(r['image_seed'])==seed and r['network']==('1' if model=='harmonic' else model)],key=lambda r:int(r['blur_scale']))
            key=('harmonic_mse' if metric=='gap_mse' else 'harmonic_r') if model=='harmonic' else metric
            ax.plot([int(r['blur_scale']) for r in part],[float(r[key]) for r in part],
                    color=color,marker='*' if seed==0 else 'o',alpha=.9 if seed==0 else .35,
                    ls='--' if model=='harmonic' else '-',label=('Matched harmonic' if model=='harmonic' else 'N'+model) if seed==0 else None)
        means=[np.mean([float(r[key]) for r in rows if r['blur_scale']==str(scale) and r['network']==('1' if model=='harmonic' else model)]) for scale in [4,8]]
        ax.plot([4,8],means,color=color,lw=2.5)
    ax.set_title(title);ax.set_xticks([4,8]);ax.set_xlabel('Noise blur scale');ax.grid(alpha=.2)
axes[0].set_yscale('log');axes[0].legend();axes[1].set_ylim(-1.05,1.05)
fig.suptitle('Five independent images | model seed fixed at 0 | stars = original image 0 | thick lines = means')
(ROOT/'figures').mkdir(exist_ok=True)
fig.savefig(ROOT/'figures/noise_baseline_validation.png',dpi=180)
plt.close(fig)
print('Meeting figure: 20 validation records; matched baseline uses same hidden pixels.')
