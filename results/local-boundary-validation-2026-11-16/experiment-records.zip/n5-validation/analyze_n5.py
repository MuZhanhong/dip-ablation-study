"""Audit N5 follow-up records and describe paired gap and depth effects."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import csv
import hashlib
import json
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from skimage.metrics import structural_similarity

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source_repository'))
from run_local_sweeps import source_hashes
from src.synthetic_data import make_image
from src.masks import central_gap_mask,heldout_mask
from baselines.fill import harmonic_fill
FIG=ROOT/'figures';FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})

def js(p):return json.loads(p.read_text(encoding='utf-8'))
def output(name,rows):
    if not rows:return
    with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def stat(p,y):
    p,y=p.astype(float),y.astype(float)
    return float(np.mean((p-y)**2)),float(np.corrcoef(p,y)[0,1]) if min(p.std(),y.std())>1e-12 else None
def ms(x):return float(np.mean(x)),float(np.std(x,ddof=1)) if len(x)>1 else None

def main():
    for rel,digest in js(ROOT/'frozen_plan_hashes.json')['sha256'].items():
        assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest,rel
    source=source_hashes(ROOT/'source_repository')
    manifest=js(ROOT/'batch-n5/manifest.json');assert source==manifest['source_sha256']
    rows=[];profiles=[];records={};baselines={};fingerprints={}
    markers=list((ROOT/'reference-seed0').glob('*/attempt_*/COMPLETE.json'))+list((ROOT/'batch-n5/runs').glob('*/attempt_*/COMPLETE.json'))
    ids=set()
    for marker in sorted(markers):
        p=marker.parent;summary=js(marker);cfg=js(p/'config.json');env=js(p/'environment.json')
        origin='reference' if 'reference-seed0' in p.parts else 'new'
        assert env['source_sha256']==source
        assert env['runner_sha256']==hashlib.sha256((ROOT/'run_local_sweeps.py').read_bytes()).hexdigest()
        if origin=='new':
            expected=next(j for j in manifest['jobs'] if j['run_id']==cfg['run_id'])
            assert all(cfg[k]==v for k,v in expected.items())
        gap_size=cfg['gap_size'];seed=cfg['model_seed']
        assert cfg['network']==5 and gap_size in [24,32] and seed in range(5)
        assert cfg['image_seed']==cfg['heldout_seed']==0 and cfg['selection']=='heldout'
        assert (gap_size,seed) not in ids;ids.add((gap_size,seed))
        y=np.load(p/'target.npy',allow_pickle=False);pred=np.load(p/'selected_prediction.npy',allow_pickle=False)
        final=np.load(p/'final_prediction.npy',allow_pickle=False)
        with np.load(p/'masks.npz',allow_pickle=False) as f:gap,held=f['gap'],f['heldout']
        assert np.array_equal(y,make_image('stripes',size=64,seed=0))
        assert np.array_equal(gap,central_gap_mask(64,gap_size))
        assert np.array_equal(held,heldout_mask(gap,.05,0))
        assert not np.any(gap&held) and all(np.isfinite(a).all() for a in [y,pred,final])
        fingerprint=hashlib.sha256(y.tobytes()+gap.tobytes()+held.tobytes()).hexdigest()
        assert fingerprints.setdefault(gap_size,fingerprint)==fingerprint
        history=list(csv.DictReader((p/'metrics.csv').open(encoding='utf-8')))
        assert [int(float(t['step'])) for t in history]==list(range(50,2001,50))
        assert all(np.isfinite(float(t[k])) for t in history for k in ['train_mse','heldout_mse','gap_mse','ssim'])
        chosen=min(history,key=lambda t:float(t['heldout_mse']))
        assert int(float(chosen['step']))==summary['selected_step']
        mse,r=stat(pred[gap],y[gap]);fmse,fr=stat(final[gap],y[gap])
        assert np.isclose(mse,float(chosen['gap_mse']),atol=1e-8,rtol=1e-5)
        assert np.isclose(fmse,float(history[-1]['gap_mse']),atol=1e-8,rtol=1e-5)
        yy,xx=np.where(gap);cut=np.s_[yy.min():yy.max()+1,xx.min():xx.max()+1]
        score=float(structural_similarity(y[cut],pred[cut],data_range=1.,win_size=3))
        assert np.isclose(score,float(chosen['ssim']),atol=1e-7)
        if gap_size not in baselines:
            unknown=gap|held;baseline=harmonic_fill(y,unknown);tamper=y.copy();tamper[unknown]=-7
            assert np.array_equal(baseline,harmonic_fill(tamper,unknown))
            assert np.array_equal(baseline[~unknown],y[~unknown])
            baselines[gap_size]=stat(baseline[gap],y[gap])
        row=dict(record_id=origin+'_'+cfg['run_id'],origin=origin,network=5,gap_size=gap_size,model_seed=seed,
                 image_seed=0,selected_step=summary['selected_step'],gap_mse=mse,gap_r=r,
                 final_gap_mse=fmse,final_gap_r=fr,ssim_3x3=score,
                 harmonic_mse=baselines[gap_size][0],harmonic_r=baselines[gap_size][1],
                 runtime_seconds=summary['runtime_seconds'],artifact_dir=p.relative_to(ROOT).as_posix(),
                 target_mask_sha256=fingerprint)
        rows.append(row);records[(gap_size,seed)]=(y,pred,gap)
        iy,ix=np.indices(y.shape)
        depth=np.minimum.reduce([iy-yy.min()+1,yy.max()-iy+1,ix-xx.min()+1,xx.max()-ix+1])
        for d in range(1,gap_size//2+1):
            region=gap&(depth==d);dmse,dr=stat(pred[region],y[region])
            profiles.append(dict(gap_size=gap_size,model_seed=seed,depth=d,pixels=int(region.sum()),mse=dmse,r=dr))
        rings=[r for r in profiles if r['gap_size']==gap_size and r['model_seed']==seed]
        assert sum(r['pixels'] for r in rings)==gap.sum()
        assert np.isclose(sum(r['pixels']*r['mse'] for r in rings)/gap.sum(),mse,atol=1e-12,rtol=1e-10)
    rows.sort(key=lambda r:(r['gap_size'],r['model_seed']))
    output('n5_seed_level.csv',rows);output('depth_profiles.csv',profiles)
    summary=[]
    for cohort in ['all_five','new_only']:
        for size in [24,32]:
            part=[r for r in rows if r['gap_size']==size and (cohort=='all_five' or r['origin']=='new')]
            if not part:continue
            r=dict(cohort=cohort,gap_size=size,n=len(part))
            for metric in ['gap_mse','gap_r','final_gap_mse']:
                r[metric+'_mean'],r[metric+'_sd']=ms([v[metric] for v in part])
            summary.append(r)
    output('n5_summary.csv',summary)
    paired=[]
    for seed in range(5):
        a=next((r for r in rows if r['gap_size']==32 and r['model_seed']==seed),None)
        b=next((r for r in rows if r['gap_size']==24 and r['model_seed']==seed),None)
        if a and b:paired.append(dict(model_seed=seed,mse_gap32_minus_gap24=a['gap_mse']-b['gap_mse'],
                                     r_gap32_minus_gap24=a['gap_r']-b['gap_r']))
    output('paired_differences.csv',paired)
    paired_summary=[]
    for cohort in ['all_five','new_only']:
        part=[r for r in paired if cohort=='all_five' or r['model_seed']!=0]
        if part:
            mean,sd=ms([r['mse_gap32_minus_gap24'] for r in part])
            paired_summary.append(dict(cohort=cohort,n=len(part),mean_mse_difference=mean,sample_sd=sd,
                                       gap32_better=sum(r['mse_gap32_minus_gap24']<0 for r in part)))
    output('paired_summary.csv',paired_summary)
    depth_summary=[]
    for size in [24,32]:
        for d in range(1,size//2+1):
            part=[r for r in profiles if r['gap_size']==size and r['depth']==d]
            if not part:continue
            mm,sd=ms([r['mse'] for r in part]);rm,rs=ms([r['r'] for r in part])
            depth_summary.append(dict(gap_size=size,depth=d,n=len(part),pixels_per_seed=part[0]['pixels'],
                                      mse_mean=mm,mse_sd=sd,r_mean=rm,r_sd=rs))
    output('depth_summary.csv',depth_summary)
    edge_comparisons=[]
    for size,seed in sorted(ids):
        edge=next(r for r in profiles if r['gap_size']==size and r['model_seed']==seed and r['depth']==1)
        inner=next(r for r in profiles if r['gap_size']==size and r['model_seed']==seed and r['depth']==8)
        edge_comparisons.append(dict(gap_size=size,model_seed=seed,edge_pixels=edge['pixels'],depth8_pixels=inner['pixels'],
            edge_mse=edge['mse'],depth8_mse=inner['mse'],edge_r=edge['r'],depth8_r=inner['r'],
            mse_depth8_minus_edge=inner['mse']-edge['mse'],r_depth8_minus_edge=inner['r']-edge['r']))
    output('edge_depth8_comparison.csv',edge_comparisons)
    audit=dict(updated_local=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),new_completed=sum(r['origin']=='new' for r in rows),
               reference_rows=sum(r['origin']=='reference' for r in rows),all_record_checks_passed=True,
               failed_attempts=len(list((ROOT/'batch-n5/runs').glob('*/attempt_*/FAILED.json'))),
               new_training_seconds=sum(r['runtime_seconds'] for r in rows if r['origin']=='new'))
    if (ROOT/'checkpoint_verification.csv').exists():
        checks=list(csv.DictReader((ROOT/'checkpoint_verification.csv').open(encoding='utf-8-sig')))
        assert len(checks)==audit['new_completed']*2 and all(r['passed']=='True' for r in checks)
        audit.update(checkpoint_reconstructions=len(checks),checkpoint_max_absolute_error=max(float(r['max_absolute_error']) for r in checks))
    (ROOT/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    figures(rows,profiles,records);report(rows,summary,paired_summary,depth_summary,audit)
    print(json.dumps(audit,ensure_ascii=False))

def figures(rows,profiles,records):
    fig,axes=plt.subplots(1,2,figsize=(11,4.4),constrained_layout=True)
    for seed in range(5):
        part=sorted([r for r in rows if r['model_seed']==seed],key=lambda r:r['gap_size'])
        for ax,metric in zip(axes,['gap_mse','gap_r']):
            ax.plot([r['gap_size'] for r in part],[r[metric] for r in part],
                    marker='*' if seed==0 else 'o',color='#d95f02' if seed==0 else '#2166ac',
                    alpha=.9 if seed==0 else .4,label='Original seed 0' if seed==0 else ('New seeds 1-4' if seed==1 else None))
    for ax,metric in zip(axes,['gap_mse','gap_r']):
        means=[];sds=[]
        for size in [24,32]:
            a=[r[metric] for r in rows if r['gap_size']==size];means.append(np.mean(a));sds.append(np.std(a,ddof=1) if len(a)>1 else 0)
        ax.errorbar([24.2,32.2],means,yerr=sds,fmt='s',color='#222222',capsize=4,label='Mean +/- sample SD')
        ax.set_xticks([24,32]);ax.set_xlabel('Stripe gap width');ax.grid(alpha=.2)
    axes[0].set_title('Selected gap MSE');axes[1].set_title('Selected gap correlation');axes[1].set_ylim(-1.05,1.05)
    axes[0].legend(fontsize=8);fig.suptitle('N5 paired model-seed validation | 2,000 steps')
    fig.savefig(FIG/'n5_gap_comparison.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
    for col,size in enumerate([24,32]):
        for seed in range(5):
            part=[r for r in profiles if r['gap_size']==size and r['model_seed']==seed]
            for ax,metric in zip(axes[:,col],['mse','r']):
                ax.plot([r['depth'] for r in part],[r[metric] for r in part],color='#d95f02' if seed==0 else '#2166ac',alpha=.8 if seed==0 else .3)
        depths=sorted({r['depth'] for r in profiles if r['gap_size']==size})
        for ax,metric in zip(axes[:,col],['mse','r']):
            ax.plot(depths,[np.mean([r[metric] for r in profiles if r['gap_size']==size and r['depth']==d]) for d in depths],color='#222222',lw=2,label='Five-seed mean')
            ax.set_xlabel('Depth from gap edge (pixels)');ax.grid(alpha=.2)
        axes[0,col].set_yscale('log');axes[0,col].set_title(f'Gap {size}: ring-wise MSE')
        axes[1,col].set_title(f'Gap {size}: ring-wise correlation');axes[1,col].set_ylim(-1.05,1.05)
    axes[0,0].legend();fig.suptitle('N5 edge-to-centre profiles | orange = original seed 0 | blue = new seeds')
    fig.savefig(FIG/'n5_depth_profiles.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(2,5,figsize=(13,5),constrained_layout=True)
    for row,size in enumerate([24,32]):
        for seed in range(5):
            ax=axes[row,seed];ax.set_xticks([]);ax.set_yticks([])
            if (size,seed) not in records:continue
            y,p,gap=records[(size,seed)];yy,xx=np.where(gap);cut=np.s_[yy.min():yy.max()+1,xx.min():xx.max()+1]
            ax.imshow(np.concatenate([y[cut],p[cut]],axis=1),cmap='gray',vmin=0,vmax=1,interpolation='nearest')
            ax.axvline(size-.5,color='#e64b35',lw=.8);mse,r=stat(p[gap],y[gap])
            ax.set_title(f'seed {seed} | MSE {mse:.3g} | r {r:.2f}',fontsize=8)
        axes[row,0].set_ylabel(f'Gap {size}')
    fig.suptitle('N5 reconstructions | each panel: gap truth (left), selected prediction (right)')
    fig.savefig(FIG/'n5_gap_grids.png',dpi=180);plt.close(fig)

def report(rows,summary,paired,depth,audit):
    lines=['# N5缺口宽度与深度验证','',f'新增完成{audit["new_completed"]}/8次训练，另纳入2个原始seed 0参考条件；累计{72+audit["new_completed"]}次独立训练。','',
        '## 问题与方法','','检验首轮N5在gap=32优于gap=24的现象，以及缺口边缘与内部的差异是否在更多模型种子下重复。新增model seed=1/2/3/4，image seed与held-out seed固定0；model seed同时改变权重初始化和固定输入噪声。','',
        'N5仍为无pooling/upsampling的共享3×3网络，16通道、4层级、2000步、Adam lr=0.01，每50步记录；按最低已记录held-out MSE选checkpoint，gap误差不参与选择，预测保持training mode。SSIM固定3×3。原模型、数据和训练代码均未修改。','',
        '## 五种子与新增四种子汇总','','| 样本组 | gap | n | gap MSE均值±样本SD | r均值±样本SD |','|---|---:|---:|---:|---:|']
    for r in summary:
        if r['gap_mse_sd'] is not None:
            lines.append(f'| {r["cohort"]} | {r["gap_size"]} | {r["n"]} | {r["gap_mse_mean"]:.6f} ± {r["gap_mse_sd"]:.6f} | {r["gap_r_mean"]:.3f} ± {r["gap_r_sd"]:.3f} |')
    lines+=['','负配对差（gap32−gap24）代表gap=32误差更低。SD为种子间样本标准差，不是置信区间。','']
    for r in paired:
        lines.append(f'- {r["cohort"]}：gap32更好{r["gap32_better"]}/{r["n"]}个种子；平均MSE差{r["mean_mse_difference"]:.6f}。')
    lines+=['','![对比](figures/n5_gap_comparison.png)','','## 边缘到中央','','![深度](figures/n5_depth_profiles.png)','','每个深度按同一圈像素计算MSE与相关性，然后跨种子描述。最内圈只有4个像素，相关性波动不能当作稳定机制证据。原始与新增种子均展示，不剔除异常输出。','',
        '![重建](figures/n5_gap_grids.png)','','## 核查与限制','',
        f'已完成记录均通过源文件哈希、配置、target/mask重建、checkpoint选择、MSE/SSIM重算和harmonic隐藏值不变性检查。新增训练耗时{audit["new_training_seconds"]/60:.2f}分钟，失败尝试{audit["failed_attempts"]}。保存权重还原预测检查数为{audit.get("checkpoint_reconstructions",0)}，最大绝对差为{audit.get("checkpoint_max_absolute_error","待核查")}。','',
        '这是首轮探索后选定条件的验证。五种子结果包含用于提出问题的原始seed 0，因此另提供新增四种子的汇总。所有目标均为同一条纹图；不能推广为独立图片上的分布结论。','',
        '改变gap同时改变训练区域与held-out抽样集合，当前对照不单独隔离几何距离。随机噪声输入、共享参数和BatchNorm也意味着几何感受野不是缺口失败的硬阈值。','',
        'GitHub上传与群组消息继续暂缓。','']
    if (ROOT/'结果解释.md').exists():
        idx=lines.index('## 五种子与新增四种子汇总');lines[idx:idx]=[(ROOT/'结果解释.md').read_text(encoding='utf-8'),'']
    (ROOT/'N5验证结果.md').write_text('\n'.join(lines),encoding='utf-8')

if __name__=='__main__':main()
