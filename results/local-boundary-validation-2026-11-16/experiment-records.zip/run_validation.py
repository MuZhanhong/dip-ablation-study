"""Execute the model-seed batch first, then the independent-image batch."""
from pathlib import Path
from types import SimpleNamespace
import argparse
from run_local_sweeps import run

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--device',choices=['cuda','cpu'],default='cuda')
args=parser.parse_args()
for kind in ['model_seed','image_seed']:
    print('BATCH',kind,flush=True)
    run(SimpleNamespace(command='run',batch=ROOT/f'batch-{kind}',device=args.device,
                        threads=4,limit=0))
