"""Audit the original 40 and follow-up 32 runs; analyse paired seed validation."""
from pathlib import Path
from collections import defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo
import csv
import hashlib
import json
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from skimage.metrics import structural_similarity

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source_repository'))
from baselines.fill import harmonic_fill
from src.synthetic_data import make_image
from src.masks import central_gap_mask,heldout_mask
from run_local_sweeps import source_hashes
FIG=ROOT/'figures';FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
COLORS={1:'#2166ac',3:'#7b3294'}

def js(p):return json.loads(p.read_text(encoding='utf-8'))
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def csvout(name,rows):
    if not rows:return
    with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def stat(p,y):
    p,y=p.astype(float),y.astype(float)
    return float(np.mean((p-y)**2)),float(np.corrcoef(p,y)[0,1]) if min(p.std(),y.std())>1e-12 else None
def mean_sd(values):return float(np.mean(values)),float(np.std(values,ddof=1)) if len(values)>1 else None

def collect():
    frozen=js(ROOT/'frozen_plan_hashes.json')
    for rel,digest in frozen['sha256'].items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest,rel
    source=source_hashes(ROOT/'source_repository')
    rows,records,cache=[],{},{}
    roots=[('original',ROOT/'original-exploration'/'batch'),
           ('model_seed',ROOT/'batch-model_seed'),('image_seed',ROOT/'batch-image_seed')]
    identities=set();fingerprints={}
    for origin,batch in roots:
        manifest=js(batch/'manifest.json');assert manifest['source_sha256']==source
        for job in manifest['jobs']:
            matches=list((batch/'runs'/job['run_id']).glob('attempt_*/COMPLETE.json'))
            if not matches:continue
            assert len(matches)==1
            p=matches[0].parent;summary=js(matches[0]);cfg=js(p/'config.json');env=js(p/'environment.json')
            assert all(cfg[k]==v for k,v in job.items())
            assert env['source_sha256']==source
            runner=ROOT/('original-exploration/run_local_sweeps.py' if origin=='original' else 'run_local_sweeps.py')
            assert env['runner_sha256']==hashlib.sha256(runner.read_bytes()).hexdigest()
            y=np.load(p/'target.npy',allow_pickle=False);pred=np.load(p/'selected_prediction.npy',allow_pickle=False)
            final=np.load(p/'final_prediction.npy',allow_pickle=False)
            with np.load(p/'masks.npz',allow_pickle=False) as m:gap,held=m['gap'],m['heldout']
            assert np.array_equal(y,make_image(job['image_type'],size=64,seed=job['image_seed'],blur_scale=job['blur_scale'] or 0))
            assert np.array_equal(gap,central_gap_mask(64,job['gap_size']))
            assert np.array_equal(held,heldout_mask(gap,.05,0))
            assert not np.any(gap&held)
            assert all(np.isfinite(a).all() for a in [y,pred,final])
            identity=(job['image_type'],job['network'],job['gap_size'],job['blur_scale'],job['image_seed'],job['model_seed'])
            assert identity not in identities,identity
            identities.add(identity)
            history=list(csv.DictReader((p/'metrics.csv').open(encoding='utf-8')))
            assert [int(float(t['step'])) for t in history]==list(range(50,2001,50))
            assert all(np.isfinite(float(t[k])) for t in history for k in ['train_mse','heldout_mse','gap_mse','ssim'])
            selected=next(t for t in history if int(float(t['step']))==summary['selected_step'])
            if job['selection']=='heldout':assert selected==min(history,key=lambda t:float(t['heldout_mse']))
            else:assert summary['selected_step']==2000 and np.array_equal(pred,final)
            mse,r=stat(pred[gap],y[gap]);fmse,fr=stat(final[gap],y[gap])
            assert np.isclose(mse,float(selected['gap_mse']),rtol=1e-5,atol=1e-8)
            assert np.isclose(fmse,float(history[-1]['gap_mse']),rtol=1e-5,atol=1e-8)
            yy,xx=np.where(gap);cut=np.s_[yy.min():yy.max()+1,xx.min():xx.max()+1]
            score=float(structural_similarity(y[cut],pred[cut],data_range=1.,win_size=3))
            assert np.isclose(score,float(selected['ssim']),atol=1e-7)
            target_key=(job['image_type'],job['gap_size'],job['blur_scale'],job['image_seed'])
            digest=hashlib.sha256(y.tobytes()+gap.tobytes()+held.tobytes()).hexdigest()
            assert fingerprints.setdefault(target_key,digest)==digest
            if target_key not in cache:
                unknown=gap|held;base=harmonic_fill(y,unknown)
                tamper=y.copy();tamper[unknown]=-7
                assert np.array_equal(base,harmonic_fill(tamper,unknown))
                assert np.array_equal(base[~unknown],y[~unknown])
                hmse,hr=stat(base[gap],y[gap])
                cache[target_key]=(hmse,hr,base)
            hmse,hr,_=cache[target_key]
            family='model_seed' if job['image_type']=='stripes' and job['network'] in [1,3] and job['gap_size'] in [16,24] else (
                'image_seed' if job['image_type']=='blurred_noise' and job['network'] in [1,3] and job['blur_scale'] in [4,8] else 'exploration_only')
            key=origin+'_'+job['run_id']
            row=dict(record_id=key,origin=origin,family=family,**job,selected_step=summary['selected_step'],
                     gap_mse=mse,gap_r=r,final_gap_mse=fmse,final_gap_r=fr,ssim_3x3=score,
                     harmonic_mse=hmse,harmonic_r=hr,mse_over_harmonic=mse/hmse,
                     prediction_mean=float(pred[gap].mean()),prediction_sd=float(pred[gap].std()),
                     target_mean=float(y[gap].mean()),target_sd=float(y[gap].std()),
                     runtime_seconds=summary['runtime_seconds'],target_mask_sha256=digest,
                     artifact_dir=p.relative_to(ROOT).as_posix())
            rows.append(row);records[key]=(y,pred,final,gap,held)
    csvout('all_72_runs.csv',rows)
    baseline_rows=[];baseline_arrays={}
    for i,(key,(mse,r,prediction)) in enumerate(sorted(cache.items(),key=lambda pair:str(pair[0]))):
        name=f'baseline_{i:03d}'
        baseline_rows.append(dict(array_key=name,image_type=key[0],gap_size=key[1],blur_scale=key[2],
                                  image_seed=key[3],harmonic_mse=mse,harmonic_r=r))
        baseline_arrays[name]=prediction
    csvout('harmonic_baselines.csv',baseline_rows)
    np.savez_compressed(ROOT/'harmonic_predictions.npz',**baseline_arrays)
    validation=[r for r in rows if r['family']!='exploration_only']
    csvout('validation_seed_level.csv',validation)
    return rows,validation,records,cache

def summarize(validation):
    groups=defaultdict(list)
    for r in validation:
        factor=r['gap_size'] if r['family']=='model_seed' else r['blur_scale']
        groups[(r['family'],r['network'],factor)].append(r)
    summary=[]
    for (family,net,factor),part in sorted(groups.items()):
        item=dict(family=family,network=net,factor=factor,n=len(part))
        for metric in ['gap_mse','gap_r','final_gap_mse','harmonic_mse','mse_over_harmonic']:
            item[metric+'_mean'],item[metric+'_sd']=mean_sd([r[metric] for r in part])
        item['better_than_harmonic']=sum(r['gap_mse']<r['harmonic_mse'] for r in part)
        summary.append(item)
    csvout('validation_summary.csv',summary)
    new_only=[]
    for (family,net,factor),part in sorted(groups.items()):
        part=[r for r in part if r['origin']!='original']
        if not part:continue
        item=dict(family=family,network=net,factor=factor,n=len(part))
        for metric in ['gap_mse','gap_r','final_gap_mse','harmonic_mse','mse_over_harmonic']:
            item[metric+'_mean'],item[metric+'_sd']=mean_sd([r[metric] for r in part])
        item['better_than_harmonic']=sum(r['gap_mse']<r['harmonic_mse'] for r in part)
        new_only.append(item)
    csvout('new_only_summary.csv',new_only)
    lookup={}
    for r in validation:
        family=r['family'];seed=r['model_seed'] if family=='model_seed' else r['image_seed']
        factor=r['gap_size'] if family=='model_seed' else r['blur_scale']
        lookup[(family,r['network'],factor,seed)]=r
    contrasts=[]
    definitions=[('model_seed','N1 gap24 - gap16',(1,24),(1,16)),
                 ('model_seed','N3 gap24 - gap16',(3,24),(3,16)),
                 ('model_seed','gap16 N3 - N1',(3,16),(1,16)),
                 ('model_seed','gap24 N3 - N1',(3,24),(1,24)),
                 ('image_seed','blur4 N3 - N1',(3,4),(1,4)),
                 ('image_seed','blur8 N3 - N1',(3,8),(1,8))]
    for family,name,a,b in definitions:
        for seed in range(5):
            ra=lookup.get((family,*a,seed));rb=lookup.get((family,*b,seed))
            if ra is not None and rb is not None:
                contrasts.append(dict(family=family,contrast=name,seed=seed,
                    mse_difference=ra['gap_mse']-rb['gap_mse'],r_difference=ra['gap_r']-rb['gap_r']))
    csvout('paired_differences.csv',contrasts)
    paired=[]
    for family,name,_,_ in definitions:
        part=[r for r in contrasts if r['contrast']==name]
        if not part:continue
        mean,sd=mean_sd([r['mse_difference'] for r in part])
        paired.append(dict(family=family,contrast=name,n=len(part),mse_difference_mean=mean,
                           mse_difference_sd=sd,negative_seeds=sum(r['mse_difference']<0 for r in part)))
    csvout('paired_summary.csv',paired)
    new_paired=[]
    for family,name,_,_ in definitions:
        part=[r for r in contrasts if r['contrast']==name and r['seed']!=0]
        if not part:continue
        mean,sd=mean_sd([r['mse_difference'] for r in part])
        new_paired.append(dict(family=family,contrast=name,n=len(part),mse_difference_mean=mean,
                              mse_difference_sd=sd,negative_seeds=sum(r['mse_difference']<0 for r in part)))
    csvout('new_only_paired_summary.csv',new_paired)
    return summary,contrasts,paired

def figures(validation,contrasts,records):
    fig,axes=plt.subplots(2,2,figsize=(12,9),constrained_layout=True)
    for i,family in enumerate(['model_seed','image_seed']):
        factors=[16,24] if family=='model_seed' else [4,8]
        for net in [1,3]:
            for seed in range(5):
                part=sorted([r for r in validation if r['family']==family and r['network']==net and
                             r['model_seed' if i==0 else 'image_seed']==seed],key=lambda r:r['gap_size'] if i==0 else r['blur_scale'])
                xs=[r['gap_size'] if i==0 else r['blur_scale'] for r in part]
                for ax,metric in zip(axes[i],['gap_mse','gap_r']):
                    ax.plot(xs,[r[metric] for r in part],color=COLORS[net],alpha=.8 if seed==0 else .4,
                            marker='*' if seed==0 else 'o',ms=10 if seed==0 else 5,
                            ls='--' if seed==0 else '-',label=f'N{net}' if seed==0 else None)
            part=[r for r in validation if r['family']==family and r['network']==net]
            for ax,metric in zip(axes[i],['gap_mse','gap_r']):
                means=[];sds=[];xs=[]
                for f in factors:
                    values=[r[metric] for r in part if (r['gap_size'] if i==0 else r['blur_scale'])==f]
                    if values:
                        means.append(np.mean(values));sds.append(np.std(values,ddof=1) if len(values)>1 else 0);xs.append(f)
                ax.errorbar(np.asarray(xs)+(-.3 if net==1 else .3)*(1 if i==0 else .25),means,yerr=sds,
                            color=COLORS[net],fmt='s',capsize=4,ms=7,lw=2)
        axes[i,0].set_title(('Model-seed' if i==0 else 'Independent-image')+' validation: MSE')
        axes[i,1].set_title(('Model-seed' if i==0 else 'Independent-image')+' validation: correlation')
        axes[i,1].set_ylim(-1.05,1.05)
        for ax in axes[i]:
            ax.set_xticks(factors);ax.set_xlabel('Stripe gap width' if i==0 else 'Noise blur scale');ax.grid(alpha=.2)
    axes[0,0].legend();axes[1,0].legend()
    fig.suptitle('Follow-up validation | stars/dashed = original seed 0 | squares/error bars = mean +/- sample SD')
    fig.savefig(FIG/'validation_overview.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(2,3,figsize=(14,7),constrained_layout=True)
    for ax,name in zip(axes.flat,dict.fromkeys(r['contrast'] for r in contrasts)):
        part=[r for r in contrasts if r['contrast']==name]
        ax.axhline(0,color='#777777',ls='--');ax.scatter([r['seed'] for r in part],[r['mse_difference'] for r in part],c=['#d95f02' if r['seed']==0 else '#2166ac' for r in part],s=50)
        ax.set_title(name);ax.set_xlabel('Model seed' if part[0]['family']=='model_seed' else 'Image seed');ax.set_xticks(range(5));ax.set_ylabel('Paired MSE difference');ax.grid(alpha=.2)
    fig.suptitle('Every paired difference | negative means the first named condition has lower MSE')
    fig.savefig(FIG/'paired_differences.png',dpi=180);plt.close(fig)
    for family in ['model_seed','image_seed']:
        fig,axes=plt.subplots(4,5,figsize=(12,10),constrained_layout=True)
        factors=[16,24] if family=='model_seed' else [4,8]
        for row,(net,factor) in enumerate([(n,f) for n in [1,3] for f in factors]):
            for seed in range(5):
                r=next((r for r in validation if r['family']==family and r['network']==net and
                    (r['gap_size'] if family=='model_seed' else r['blur_scale'])==factor and
                    r['model_seed' if family=='model_seed' else 'image_seed']==seed),None)
                ax=axes[row,seed];ax.set_xticks([]);ax.set_yticks([])
                if r:
                    y,p,_,gap,_=records[r['record_id']]
                    # Show gap prediction next to its own truth; targets change across image seeds.
                    yy,xx=np.where(gap);cut=np.s_[yy.min():yy.max()+1,xx.min():xx.max()+1]
                    ax.imshow(np.concatenate([y[cut],p[cut]],axis=1),cmap='gray',vmin=0,vmax=1,interpolation='nearest')
                    ax.axvline(r['gap_size']-.5,color='#e64b35',lw=.8)
                    ax.set_title(f'seed {seed}: MSE {r["gap_mse"]:.3g}, r {r["gap_r"]:.2f}',fontsize=8)
            axes[row,0].set_ylabel(f'N{net} '+('gap ' if family=='model_seed' else 'blur ')+str(factor))
        fig.suptitle(f'{family.replace("_"," ")} validation | each panel: gap truth (left), prediction (right)')
        fig.savefig(FIG/f'{family}_gap_grids.png',dpi=170);plt.close(fig)

def report(allrows,validation,summary,paired,audit):
    lines=['# Yudi 后续32次验证实验','',f'状态：新增{audit["new_completed"]}/32；累计{len(allrows)}/72次独立训练记录。','',
        '## 本轮检验什么','',
        '依据首轮40次探索结果选择两组后续验证，并在新增训练前冻结计划。模型种子组：N1/N3、条纹gap=16/24、model seed=1/2/3/4，固定image seed=0。独立图片组：N1/N3、blur=4/8、image seed=1/2/3/4，固定model seed=0。每组16次新增训练，分析时纳入对应的4个原始seed 0条件，各形成20行、每条件5个种子的结果。原始记录未重跑、未计为新增训练。','',
        '模型种子改变权重初始化和固定输入噪声；图片种子改变目标噪声图片。两种不确定性分开分析。本轮不是image seed×model seed交叉设计，不估计二者的交互。','',
        '## 协议','',
        '其余设置沿用首轮：64×64、16通道、4层级、2000步、Adam lr=0.01、每50步记录、held-out seed=0、training-mode预测、SSIM 3×3。N1/N3均按最低已记录held-out MSE选择checkpoint；gap真值仅评价。harmonic同时隐藏gap与held-out，与训练信息匹配。','',
        '均值±SD中的SD是5个种子分数的样本标准差，描述当前条件的波动；不是均值的标准误或置信区间。配对差值按相同种子计算，不把gap像素当成独立重复，不报告多重比较后的显著性结论。由于seed 0曾用于选择问题，另在new_only_summary.csv和new_only_paired_summary.csv中单独提供新增seed 1～4的汇总，避免把原观察当作独立验证。','',
        '## 五种子汇总','',
        '| 组别 | 网络 | gap或blur | n | gap MSE均值±SD | r均值±SD | 优于harmonic的种子数 |',
        '|---|---|---:|---:|---:|---:|---:|']
    for r in summary:
        sd=r['gap_mse_sd'];rsd=r['gap_r_sd']
        lines.append(f'| {r["family"]} | N{r["network"]} | {r["factor"]} | {r["n"]} | {r["gap_mse_mean"]:.6f} ± {sd:.6f} | {r["gap_r_mean"]:.3f} ± {rsd:.3f} | {r["better_than_harmonic"]}/{r["n"]} |' if sd is not None else f'| {r["family"]} | N{r["network"]} | {r["factor"]} | {r["n"]} | {r["gap_mse_mean"]:.6f} | {r["gap_r_mean"]:.3f} | {r["better_than_harmonic"]}/{r["n"]} |')
    lines+=['','![汇总](figures/validation_overview.png)','','## 配对比较','','负差值表示名称中前一个条件的MSE更低。所有逐种子差值保存在paired_differences.csv。','',
        '| 对比 | n | 平均MSE差 | 差值样本SD | 负差值种子数 |','|---|---:|---:|---:|---:|']
    for r in paired:
        sd='—' if r['mse_difference_sd'] is None else f'{r["mse_difference_sd"]:.6f}'
        lines.append(f'| {r["contrast"]} | {r["n"]} | {r["mse_difference_mean"]:.6f} | {sd} | {r["negative_seeds"]}/{r["n"]} |')
    lines+=['','![配对](figures/paired_differences.png)','','## 逐种子重建','','每个面板左侧为对应目标的缺口真值，右侧为预测。独立图片组的目标会随列改变。','',
        '![模型种子](figures/model_seed_gap_grids.png)','','![图片种子](figures/image_seed_gap_grids.png)','','## 核查与追溯','',
        f'全部已完成记录通过配置、源文件、目标和mask重建、checkpoint选择与MSE/SSIM重算检查；失败尝试数{audit["failed_attempts"]}。新增训练累计耗时{audit["new_training_seconds"]/60:.2f}分钟。', '',
        '原始40次探索的精简记录在original-exploration；新增32次完整本机记录在两个batch目录。all_72_runs.csv用于完整索引，validation_seed_level.csv用于本轮验证；两表不能直接当作相同条件的72次重复。匹配信息的harmonic指标与数组保存在harmonic_baselines.csv及harmonic_predictions.npz。','',
        '## 当前限制','',
        '- 所有运行均来自本机CUDA，软件、源文件与设备记录用于追溯，不声明跨机器逐像素一致。',
        '- 原始seed 0参与了后续条件的选择。报告同时保留seed 0与新seed 1～4，明确这是探索后的验证；新增种子仍只有4个。',
        '- 条纹不改变image seed，因此只能检验当前固定条纹下的模型种子波动。噪声组固定model seed，尚不能分解两种种子的交互。',
        '- 改变gap会改变训练可见区域，当前mask生成器也会重新从可见位置抽取held-out。即使held-out seed相同，两个gap的held-out位置集合也不相同；本轮保留原协议，不能将gap对比全部解释为几何距离效应。',
        '- 当前目标按每张样本标准差缩放；本轮不包含精确GP条件均值基线。',
        '- GitHub上传与群组消息暂缓，等待用户后续明确要求。','']
    interpretation=ROOT/'结果解释.md'
    if interpretation.exists():
        idx=lines.index('## 五种子汇总');lines[idx:idx]=[interpretation.read_text(encoding='utf-8'),'']
    (ROOT/'验证结果报告.md').write_text('\n'.join(lines),encoding='utf-8')

def main():
    allrows,validation,records,cache=collect()
    summary,contrasts,paired=summarize(validation)
    audit=dict(updated_local=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
        new_completed=sum(r['origin']!='original' for r in allrows),original_completed=sum(r['origin']=='original' for r in allrows),
        total_unique_runs=len(allrows),validation_rows=len(validation),
        failed_attempts=sum(len(list((ROOT/f'batch-{k}'/'runs').glob('*/attempt_*/FAILED.json'))) for k in ['model_seed','image_seed']),
        all_record_checks_passed=True,new_training_seconds=sum(r['runtime_seconds'] for r in allrows if r['origin']!='original'))
    verification=ROOT/'checkpoint_verification.csv'
    if verification.exists():
        check=list(csv.DictReader(verification.open(encoding='utf-8-sig')))
        assert len(check)==audit['new_completed']*2 and all(r['passed']=='True' for r in check)
        audit.update(new_checkpoint_reconstructions=len(check),checkpoint_max_absolute_error=max(float(r['max_absolute_error']) for r in check))
    dump(ROOT/'audit.json',audit)
    figures(validation,contrasts,records);report(allrows,validation,summary,paired,audit)
    print(json.dumps(audit,ensure_ascii=False))

if __name__=='__main__':main()
